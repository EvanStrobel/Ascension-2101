﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//Place this script on an empty child gameobject of the enemy and create a box collider as trigger

public class EnemySpotlight : MonoBehaviour
{
    public bool seeInvisability;

    public float timeBeforeRespawn = 3;

    private float timeElapsed;

    //Starts the timer when player is in the trigger zone
    private void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            timeElapsed += Time.deltaTime;

            //Respawns player at last checkpoint if the player has been in the trigger zone too long
            if(timeElapsed > timeBeforeRespawn)
            {
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
            }
        }
    }

    //Restarts the timer when the player leaves the trigger zone
    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            timeElapsed = 0;
        }
    }
}
