﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Place this code in your Game Master script or script that controls the main game

public class GameMaster : MonoBehaviour
{
    private static GameMaster instance;
    public Vector3 lastCheckPointPos;
    
    //Makes sure there aren't more than one checkpoint set at a time
    void Awake()
    {
        if(instance == null)
        {
            instance = this;
            DontDestroyOnLoad(instance);
        } else
            {
                Destroy(gameObject);
            }
    }
}
