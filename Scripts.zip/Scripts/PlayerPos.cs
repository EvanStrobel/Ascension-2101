﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

//Place script on your player or copy code to the player script

public class PlayerPos : MonoBehaviour
{
    private GameMaster gm;
    
    //saves players postion at last checkpoint
    void Start()
    {
        gm = GameObject.FindGameObjectWithTag("GM").GetComponent<GameMaster>();
        transform.position = gm.lastCheckPointPos;
    }
}
