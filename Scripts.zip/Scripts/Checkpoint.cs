﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Place script on checkpoint object with box collider as trigger

public class Checkpoint : MonoBehaviour
{
    private GameMaster gm;

    private void Start()
    {
        gm = GameObject.FindGameObjectWithTag("GM").GetComponent<GameMaster>();
    }

    //sets the checkpoint as current checkpoint position
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            gm.lastCheckPointPos = transform.position;
        }
    }
}
